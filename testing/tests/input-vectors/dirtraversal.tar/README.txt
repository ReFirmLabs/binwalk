Dir traversal test
