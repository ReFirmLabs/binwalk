Subdir traversal test.
