ROI
===

.. autoclass:: pyqtgraph.ROI
    :members:

    .. automethod:: pyqtgraph.ROI.__init__

