IsocurveItem
============

.. autoclass:: pyqtgraph.IsocurveItem
    :members:

    .. automethod:: pyqtgraph.IsocurveItem.__init__
