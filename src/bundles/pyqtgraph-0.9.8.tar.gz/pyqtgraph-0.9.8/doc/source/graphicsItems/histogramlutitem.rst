HistogramLUTItem
================

.. autoclass:: pyqtgraph.HistogramLUTItem
    :members:

    .. automethod:: pyqtgraph.HistogramLUTItem.__init__

