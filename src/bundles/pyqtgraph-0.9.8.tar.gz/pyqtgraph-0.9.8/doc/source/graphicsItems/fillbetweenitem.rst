FillBetweenItem
===============

.. autoclass:: pyqtgraph.FillBetweenItem
    :members:

    .. automethod:: pyqtgraph.FillBetweenItem.__init__

