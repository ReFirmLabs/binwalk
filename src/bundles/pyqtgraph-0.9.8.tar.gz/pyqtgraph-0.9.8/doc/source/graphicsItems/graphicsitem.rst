GraphicsItem
============

.. autoclass:: pyqtgraph.GraphicsItem
    :members:

