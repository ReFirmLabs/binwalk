HoverEvent
==========

.. autoclass:: pyqtgraph.GraphicsScene.mouseEvents.HoverEvent
    :members:
