MeshData
========

.. autoclass:: pyqtgraph.opengl.MeshData
    :members:

    .. automethod:: pyqtgraph.opengl.MeshData.__init__

