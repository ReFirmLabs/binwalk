BusyCursor
==========

.. autoclass:: pyqtgraph.BusyCursor
    :members:

    .. automethod:: pyqtgraph.BusyCursor.__init__

